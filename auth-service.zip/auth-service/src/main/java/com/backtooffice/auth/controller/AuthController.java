// controller/AuthController.java
package com.backtooffice.auth.controller;

import com.backtooffice.auth.dto.LoginRequest;
import com.backtooffice.auth.dto.RegisterRequest;
import com.backtooffice.auth.dto.JwtResponse;
import com.backtooffice.auth.model.User;
import com.backtooffice.auth.service.AuthService;


import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import java.util.Collections;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;


@RestController
@RequestMapping("/api/auth")
@CrossOrigin(origins = "*", maxAge = 3600)
public class AuthController {
    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);
    
    @Autowired
    private AuthService authService;
    
    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public ResponseEntity<?> registerUser(
        @Valid @RequestBody RegisterRequest registerRequest
    ) {
        try {
            logger.info("Attempting to register user: {}", registerRequest.getUsername());
            User user = authService.registerUser(registerRequest);
            
            return ResponseEntity
                .status(HttpStatus.CREATED)
                .body("User registered successfully");
        } catch (Exception e) {
            logger.error("Registration Error", e);
            return ResponseEntity
                .badRequest()
                .body(Map.of("error", "Registration failed", "message", e.getMessage()));
        }
    }
    
        @PostMapping("/login")
        public ResponseEntity<?> login(@Valid @RequestBody LoginRequest loginRequest) {
            try {
                JwtResponse response = authService.authenticateUser(loginRequest);
                return ResponseEntity.ok(response);
            } catch (Exception e) {
                return ResponseEntity
                    .status(HttpStatus.UNAUTHORIZED)
                    .body("Login failed: " + e.getMessage());
            }
        }
    
}
