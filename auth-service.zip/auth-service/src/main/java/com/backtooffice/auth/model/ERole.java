
// model/ERole.java
package com.backtooffice.auth.model;

public enum ERole {
    ROLE_USER,
    ROLE_ADMIN
}