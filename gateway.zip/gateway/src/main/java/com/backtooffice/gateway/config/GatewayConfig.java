package com.backtooffice.gateway.config;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class GatewayConfig {
    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
        .route("auth-service", r -> r
        .path("/api/auth/**")
        .filters(f -> f.rewritePath("/api/auth/(?<segment>.*)", "/api/auth/${segment}")) // Fix path forwarding
        .uri("lb://auth-service")) // Load-balanced service URI
        .route("employee-service", r -> r
        .path("/api/employees/**")
        .filters(f -> f.rewritePath("/api/employees/(?<segment>.*)", "/api/employees/${segment}")) // Fix: Ensure correct forwarding
        .uri("lb://employee-service"))
    
                .build();
    }
}